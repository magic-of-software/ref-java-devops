/**
 * Application Events.
 */
package org.springframework.kafka.event;
