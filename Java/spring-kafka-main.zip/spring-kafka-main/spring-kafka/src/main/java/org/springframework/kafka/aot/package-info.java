/**
 * Provides classes to support Spring AOT.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.kafka.aot;
