/**
 * Provides classes related to type mapping.
 */
package org.springframework.kafka.support.mapping;