/**
 * Provides classes to support the use of MockConsumer and MockProducer.
 */
package org.springframework.kafka.mock;
