/**
 * Classes for Envers Repositories configuration support.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.envers.repository.config;
