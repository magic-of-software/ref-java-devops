@NonNullApi
package org.springframework.data.jpa.repository.custom;

import org.springframework.lang.NonNullApi;
