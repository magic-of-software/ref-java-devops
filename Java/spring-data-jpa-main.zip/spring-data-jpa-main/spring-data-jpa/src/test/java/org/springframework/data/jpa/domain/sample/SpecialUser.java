package org.springframework.data.jpa.domain.sample;

import jakarta.persistence.Entity;

/**
 * @author Oliver Gierke
 */
@Entity
public class SpecialUser extends User {

}
